package com.example.listnewsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.listnewsapp.api.ApiService;
import com.example.listnewsapp.parseData.NewsObject;
import com.example.listnewsapp.parseData.ResultsApi;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    class NewsRecyclerAdapter extends RecyclerView.Adapter<NewsRecyclerAdapter.NewsViewHolder>{

        private List<NewsObject> newsList;

        public void setNewsList(List<NewsObject> newsList){
            this.newsList = newsList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            return new NewsViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.news_item, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
            holder.newsImageView = newsList.get(position)
        }

        @Override
        public int getItemCount() {
            if (newsList != null)
                return newsList.size();
            else return 0;
        }

        class NewsViewHolder extends RecyclerView.ViewHolder{

            ImageView newsImageView;
            TextView tvNewsTitle;
            TextView tvNewsPrice;
            ImageView priceImageView;

            NewsViewHolder(@NonNull View itemView) {
                super(itemView);
                newsImageView = itemView.findViewById(R.id.news_image);
                tvNewsTitle = itemView.findViewById(R.id.news_title);
                tvNewsPrice = itemView.findViewById(R.id.price);
                priceImageView = itemView.findViewById(R.id.image_price);
            }
        }
    }

}
