package com.example.listnewsapp.api;

public class LinksApi {
    public static String getMainUrl(){
        return "http://allcom.lampawork.com";
    }
}
